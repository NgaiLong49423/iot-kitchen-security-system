#ifndef ARDUINO_SECRETS_H
#define ARDUINO_SECRETS_H

// ==================================================
// 1. WiFi Configuration
// ==================================================
// Tên WiFi ESP32-CAM sẽ kết nối
#define SECRET_SSID "Nokia A31 Ultra"

// Mật khẩu WiFi
#define SECRET_OPTIONAL_PASS "09807778"


// ==================================================
// 2. Arduino IoT Cloud Device Secret
// ==================================================
// Device Secret Key / Secret Key của thiết bị Arduino Cloud
#define SECRET_DEVICE_KEY "E#LnWVOwG1Qk@iJLRZVFD5W?e"


// ==================================================
// 3. Google Apps Script Web App
// ==================================================
// URL Web App dùng để gửi Gmail
// Ví dụ dạng thật thường bắt đầu bằng:
// https://script.google.com/macros/s/...../exec
#define SECRET_GOOGLE_SCRIPT_URL "https://script.google.com/macros/s/AKfycbxW4HIy3PNpaYm-Z7bBPZSvGjeUUqVTm1qNu44eZWWDY18YbwUSsS42uGZgatBA_xIaOg/exec"


// ==================================================
// 4. Telegram Bot
// ==================================================
// Token của bot Telegram lấy từ BotFather
#define SECRET_TELEGRAM_BOT_TOKEN "8787413705:AAE635vLwCC6hgxbpdsyTF77UMoVdzUd-Og"

// Chat ID người nhận tin nhắn Telegram
#define SECRET_TELEGRAM_CHAT_ID "-5504418728"


// ==================================================
// 5. Optional Demo Settings
// ==================================================
// Tên nhóm / tên thiết bị để gửi trong nội dung cảnh báo
#define SECRET_DEVICE_NAME "He thong canh bao bep"

// Khu vực đặt thiết bị
#define SECRET_DEVICE_LOCATION "Khu vuc bep"

#endif